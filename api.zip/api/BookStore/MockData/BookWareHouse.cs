﻿using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.MockData
{
    public interface IBookWareHouse
    {
        List<Book> GetBooks();
        bool SaveBook(Book book);
        bool DeleteBook(Book book);
        bool UpdateBook(Book book);

    }
    public class BookWareHouse : IBookWareHouse
    {
        List<Book> books = new List<Book>()
            {
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "The power of your subconscious mind",
                    Author = "Nolan",
                    Description = "This book lets you understand how your subconsious mind can control the things hapeening around you",
                    NumberofReviews = 500,
                    Rating = 4,
                    ReleasedDate = new DateTime(2004,02,03)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Subtle art",
                    Author = "Chris",
                    Description = "This book explains about subtle art",
                    NumberofReviews = 250,
                    Rating = 3.5,
                    ReleasedDate = new DateTime(2008,09,27)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Big dog",
                    Author = "John",
                    Description = "To understand the troubles of a celebrity",
                    NumberofReviews = 350,
                    Rating = 3,
                    ReleasedDate = new DateTime(2001,11,07)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Climb",
                    Author = "Mike",
                    Description = "To understand the troubles of a climber",
                    NumberofReviews = 350,
                    Rating = 2,
                    ReleasedDate = new DateTime(2001,11,07)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Naruto",
                    Author = "Kishimoto",
                    Description = "Epic",
                    NumberofReviews = 350,
                    Rating = 5,
                    ReleasedDate = new DateTime(2001,11,07)
                }
            };
        public List<Book> GetBooks()
        {
            return books;
        }

        public bool SaveBook(Book book)
        {
            try
            {
                book.Id = DateTime.Now.Ticks;
                books.Add(book);
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        public bool DeleteBook(Book book)
        {
            try
            {
                books.Remove(book);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool UpdateBook(Book book)
        {
            try
            {
                var actualBook = books.FirstOrDefault(x => x.Id == book.Id);
                if (actualBook ==null)
                {
                    return false;
                }
                else
                {
                    actualBook.Name = book.Name;
                    actualBook.Rating = book.Rating;
                    actualBook.ReleasedDate = book.ReleasedDate;
                    actualBook.NumberofReviews = book.NumberofReviews;
                    actualBook.Author = book.Author;
                    actualBook.Description = book.Description;
                    return true;
                }
            }
            catch(Exception ex)
            {
                return false;
            }
        }
    }
}
