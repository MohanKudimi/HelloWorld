﻿using BookStore.MockData;
using BookStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private IBookWareHouse _bookWareHouse;
        public BooksController(IBookWareHouse bookWareHouse)
        {
            _bookWareHouse = bookWareHouse;
        }
        [HttpGet]
        public List<Book> GetBooks()
        {
            return _bookWareHouse.GetBooks();
        }

        [HttpPost]
        public ActionResult SaveBook(Book book)
        {
            if(_bookWareHouse.SaveBook(book))
            {
                return Ok();
            }
            else
            {
                return BadRequest("Invalid Details");
            }
        }

        [HttpPut]
        public ActionResult UpdateBook(Book book)
        {
            if (book == null)
            {
                return BadRequest("Invalid Id");
            }
            else
            {
                _bookWareHouse.UpdateBook(book);
                return Ok();
            }
        }

        [HttpDelete]
        public ActionResult DeleteBook(long id)
        {
            var book = _bookWareHouse.GetBooks().FirstOrDefault(x => x.Id == id);
            if ( book == null)
            {
                return BadRequest("Invalid Id");
            }
            else
            {
                _bookWareHouse.DeleteBook(book);
                return Ok();
            }
        }
    }
}
