﻿using BookStore.Controllers;
using BookStore.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using BookStore.MockData;
using Microsoft.AspNetCore.Mvc;

namespace BookstoreTests
{
    [TestClass]
    public class BooksControllerTests
    {
        private BooksController booksController;
        private Mock<IBookWareHouse> _mockBookWareHouse;
        [TestInitialize]
        public void Setup()
        {
            _mockBookWareHouse = new Mock<IBookWareHouse>();
            _mockBookWareHouse.Setup(x => x.GetBooks()).Returns(books);
            _mockBookWareHouse.Setup(x => x.SaveBook(It.IsAny<Book>())).Returns(true);
            _mockBookWareHouse.Setup(x => x.UpdateBook(It.IsAny<Book>())).Returns(true);
            _mockBookWareHouse.Setup(x => x.DeleteBook(It.IsAny<Book>())).Returns(true);
            booksController = new BooksController(_mockBookWareHouse.Object);
        }

        [TestMethod]
        public void ShouldGetListofBooksWhenGetBooksMethodIsInvoked()
        {
            var books = booksController.GetBooks();
            Assert.AreEqual(5, books.Count);
        }

        [TestMethod]
        public void ShouldAddBookWhenSaveBookIsInvoked()
        {
            var book = new Book()
            {
                Id = DateTime.Now.Ticks,
                Name = "Race",
                Author = "Nolan",
                Description = "This race",
                NumberofReviews = 500,
                Rating = 4,
                ReleasedDate = new DateTime(2004, 02, 03)
            };
            var bookAdded = booksController.SaveBook(book) as OkResult;
            Assert.AreEqual(bookAdded.StatusCode, 200);
        }

        [TestMethod]
        public void ShouldDeleteBookWhenDeleteBookIsInvoked()
        {
            var books = booksController.GetBooks();
            var bookAdded = booksController.DeleteBook(books[0].Id) as  OkResult;
            Assert.AreEqual(bookAdded.StatusCode, 200);
        }

        [TestMethod]
        public void ShouldUpdateBookWhenUpdateBookIsInvoked()
        {
            var books = booksController.GetBooks();
            var book = new Book()
            {
                Id = books[0].Id,
                Name = "Ferrari",
                Author = "Nolan",
                Description = "This book lets you understand how your subconsious mind can control the things hapeening around you",
                NumberofReviews = 500,
                Rating = 4,
                ReleasedDate = new DateTime(2004, 02, 03)
            };
            var bookAdded = booksController.UpdateBook(book) as OkResult;
            Assert.AreEqual(bookAdded.StatusCode, 200);
        }

        List<Book> books = new List<Book>()
            {
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "The power of your subconscious mind",
                    Author = "Nolan",
                    Description = "This book lets you understand how your subconsious mind can control the things hapeening around you",
                    NumberofReviews = 500,
                    Rating = 4,
                    ReleasedDate = new DateTime(2004,02,03)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Subtle art",
                    Author = "Chris",
                    Description = "This book explains about subtle art",
                    NumberofReviews = 250,
                    Rating = 3.5,
                    ReleasedDate = new DateTime(2008,09,27)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Big dog",
                    Author = "John",
                    Description = "To understand the troubles of a celebrity",
                    NumberofReviews = 350,
                    Rating = 3,
                    ReleasedDate = new DateTime(2001,11,07)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Climb",
                    Author = "Mike",
                    Description = "To understand the troubles of a climber",
                    NumberofReviews = 350,
                    Rating = 2,
                    ReleasedDate = new DateTime(2001,11,07)
                },
                new Book()
                {
                    Id=DateTime.Now.Ticks,
                    Name = "Naruto",
                    Author = "Kishimoto",
                    Description = "Epic",
                    NumberofReviews = 350,
                    Rating = 5,
                    ReleasedDate = new DateTime(2001,11,07)
                }
            };
    }
}
