import { Component, OnInit } from '@angular/core';
import { BookStoreService } from '../Services/book-store.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.scss']
})
export class BookComponent implements OnInit {

  books = null;
  displayedColumns = ["name","author","releasedDate","description","rating","numberofReviews","wishlist"]
  constructor(private _bookStoreService: BookStoreService){

  }
  ngOnInit(): void {
    this.getBooks();
  }

  getBooks() {
    this._bookStoreService.getBooks().
    subscribe((response)=>{
      this.books = response.filter(book => book.rating >2);
    });
  }

  ShowMessage(message: string) {
    alert(message);
  }

  showallbooks($event: any) {
    if ($event.target.checked === true) {
      this._bookStoreService.getBooks().
    subscribe((response)=>{
      this.books = response;
    });
    }
    else if($event.target.checked === false) {
this.getBooks();
    }
    
  }

}
