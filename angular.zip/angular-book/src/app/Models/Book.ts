export class Book {
    public id: number;
        public name: string;
        public author: string;
        public releasedDate: string;
        public description: string;
        public rating: number;
        public numberofReviews: number;
}