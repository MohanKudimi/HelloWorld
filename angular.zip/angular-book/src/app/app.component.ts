import { Component, OnInit } from '@angular/core';
import { BookStoreService } from './Services/book-store.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Welcome to CGI';
  ngOnInit(): void {
    
  }
  
}
