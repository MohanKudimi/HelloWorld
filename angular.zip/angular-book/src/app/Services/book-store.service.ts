import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from 'src/app/Models/Book';

@Injectable({
  providedIn: 'root'
})
export class BookStoreService {

  constructor(private _httpClient: HttpClient) { }

  getBooks() {
    return this._httpClient.get<Book[]>("http://localhost:21567/api/Books");
  }
}
